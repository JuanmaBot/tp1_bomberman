#[derive(Eq, PartialEq, Hash)]
pub struct Punto {
    pub x: usize,
    pub y: usize,
}
